"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useCart } from "./CartProvider"
import { Upload, X, RotateCcw } from "lucide-react"
import Image from "next/image"

function GuitarPickDisplay({
  color = "#FFFFFF",
  material = "standard",
  customDesign = null,
}: {
  color?: string
  material?: string
  customDesign?: string | null
}) {
  const getColorOverlay = (color: string, material: string) => {
    if (color === "#FFFFFF") return "none"

    // Different overlay styles based on material
    const baseFilter = `hue-rotate(${getHueRotation(color)}deg) saturate(1.8) brightness(0.9)`

    switch (material) {
      case "metal":
        return `${baseFilter} contrast(1.2) brightness(1.1)`
      case "wood":
        return `${baseFilter} sepia(0.3) contrast(0.9) brightness(0.8)`
      default:
        return baseFilter
    }
  }

  const getColorStyle = (color: string, material: string) => {
    if (color === "#FFFFFF" || customDesign) {
      return {}
    }

    return {
      filter: getColorOverlay(color, material),
      transition: "filter 0.3s ease-in-out",
    }
  }

  return (
    <div className="flex justify-center items-center h-full">
      <div className="relative">
        {/* Base white pick image */}
        <Image
          src="/pana_alba-removebg-preview.png"
          alt="Guitar Pick"
          width={200}
          height={200}
          className="object-contain transition-all duration-300"
          style={customDesign ? {} : getColorStyle(color, material)}
        />

        {/* Custom Design Overlay */}
        {customDesign && (
          <div
            className="absolute inset-0 transition-opacity duration-300"
            style={{
              backgroundImage: `url(${customDesign})`,
              backgroundSize: "contain",
              backgroundRepeat: "no-repeat",
              backgroundPosition: "center",
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
              mixBlendMode: "multiply",
            }}
          />
        )}

        {/* Color overlay for non-white colors (only if no custom design) */}
        {color !== "#FFFFFF" && !customDesign && (
          <div
            className="absolute inset-0 mix-blend-multiply opacity-60 transition-opacity duration-300"
            style={{
              backgroundColor: color,
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
            }}
          />
        )}

        {/* Material-specific effects (only if no custom design) */}
        {!customDesign && material === "metal" && (
          <div
            className="absolute inset-0 opacity-20 transition-opacity duration-300"
            style={{
              background: "linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.8) 50%, transparent 70%)",
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
            }}
          />
        )}

        {!customDesign && material === "wood" && (
          <div
            className="absolute inset-0 opacity-15 transition-opacity duration-300"
            style={{
              background:
                "repeating-linear-gradient(90deg, rgba(139,69,19,0.3) 0px, rgba(160,82,45,0.3) 2px, rgba(139,69,19,0.3) 4px)",
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
            }}
          />
        )}
      </div>
    </div>
  )
}

function getHueRotation(color: string): number {
  const colorMap: { [key: string]: number } = {
    "#EAB308": 45, // Yellow
    "#3B82F6": 220, // Blue
    "#EF4444": 0, // Red
    "#10B981": 140, // Green
    "#F3F4F6": 0, // Light Gray
    "#FFFFFF": 0, // White
    "#8B5CF6": 280, // Purple
    "#F97316": 25, // Orange
    "#EC4899": 320, // Pink
    "#000000": 0, // Black
  }
  return colorMap[color] || 0
}

const colors = [
  { name: "White", value: "#FFFFFF" },
  { name: "Yellow", value: "#EAB308" },
  { name: "Blue", value: "#3B82F6" },
  { name: "Red", value: "#EF4444" },
  { name: "Green", value: "#10B981" },
  { name: "Purple", value: "#8B5CF6" },
  { name: "Orange", value: "#F97316" },
  { name: "Pink", value: "#EC4899" },
  { name: "Black", value: "#000000" },
]

const materials = [
  { name: "Standard", value: "standard", price: 0 },
  { name: "Metal", value: "metal", price: 5 },
  { name: "Wood", value: "wood", price: 3 },
]

const thicknesses = [
  { name: "Thin (0.5mm)", value: "thin", price: 0 },
  { name: "Medium (0.7mm)", value: "medium", price: 0 },
  { name: "Heavy (1.0mm)", value: "heavy", price: 1 },
]

export default function ProductCustomizer() {
  const [selectedColor, setSelectedColor] = useState(colors[0]) // Default to white
  const [selectedMaterial, setSelectedMaterial] = useState(materials[0])
  const [selectedThickness, setSelectedThickness] = useState(thicknesses[1])
  const [engraving, setEngraving] = useState("")
  const [customDesign, setCustomDesign] = useState<string | null>(null)
  const [designFile, setDesignFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { addToCart } = useCart()

  const basePrice = 12.99
  const customDesignPrice = customDesign ? 8 : 0 // Additional cost for custom design
  const totalPrice =
    basePrice + selectedMaterial.price + selectedThickness.price + (engraving ? 3 : 0) + customDesignPrice

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Check file type
      if (!file.type.startsWith("image/")) {
        alert("Please upload an image file (PNG, JPG, GIF, etc.)")
        return
      }

      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert("File size must be less than 5MB")
        return
      }

      setDesignFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setCustomDesign(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeCustomDesign = () => {
    setCustomDesign(null)
    setDesignFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleAddToCart = () => {
    const customPick = {
      id: `custom-${Date.now()}`,
      name: "Custom Guitar Pick",
      price: totalPrice,
      image: "/pana_alba-removebg-preview.png",
      customization: {
        color: customDesign ? "Custom Design" : selectedColor.name,
        material: selectedMaterial.name,
        thickness: selectedThickness.name,
        engraving: engraving || "None",
        customDesign: customDesign ? "Yes" : "No",
      },
    }
    addToCart(customPick)
  }

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* Guitar Pick Display */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-gray-900">Pick Preview</h3>
        <div className="h-80 flex items-center justify-center">
          <div
            className="cursor-grab active:cursor-grabbing transform transition-transform duration-200 hover:scale-110"
            onMouseDown={(e) => {
              const startX = e.clientX
              const element = e.currentTarget
              let currentRotation = 0

              const handleMouseMove = (moveEvent: MouseEvent) => {
                const deltaX = moveEvent.clientX - startX
                currentRotation = deltaX * 0.5
                element.style.transform = `rotateY(${currentRotation}deg) scale(1.1)`
              }

              const handleMouseUp = () => {
                document.removeEventListener("mousemove", handleMouseMove)
                document.removeEventListener("mouseup", handleMouseUp)
                element.style.transform = "rotateY(0deg) scale(1)"
              }

              document.addEventListener("mousemove", handleMouseMove)
              document.addEventListener("mouseup", handleMouseUp)
            }}
            onTouchStart={(e) => {
              const startX = e.touches[0].clientX
              const element = e.currentTarget
              let currentRotation = 0

              const handleTouchMove = (moveEvent: TouchEvent) => {
                const deltaX = moveEvent.touches[0].clientX - startX
                currentRotation = deltaX * 0.5
                element.style.transform = `rotateY(${currentRotation}deg) scale(1.1)`
              }

              const handleTouchEnd = () => {
                document.removeEventListener("touchmove", handleTouchMove)
                document.removeEventListener("touchend", handleTouchEnd)
                element.style.transform = "rotateY(0deg) scale(1)"
              }

              document.addEventListener("touchmove", handleTouchMove)
              document.addEventListener("touchend", handleTouchEnd)
            }}
          >
            <GuitarPickDisplay
              color={selectedColor.value}
              material={selectedMaterial.value}
              customDesign={customDesign}
            />
          </div>
        </div>

        {/* Instructions */}
        <div className="text-center">
          <p className="text-sm text-gray-500">Click and drag horizontally to rotate the pick</p>
        </div>
      </div>

      {/* Customization Options */}
      <Card className="bg-white/90 backdrop-blur-sm border-yellow-200/50 shadow-lg">
        <CardHeader>
          <CardTitle className="text-gray-900">Customize Your Pick</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Custom Design Upload */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Custom Design (+$8)</label>

            {!customDesign ? (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-yellow-400 transition-colors">
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 mb-2">Upload your design</p>
                <p className="text-xs text-gray-500 mb-3">PNG, JPG, GIF up to 5MB</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Choose File
                </Button>
              </div>
            ) : (
              <div className="border border-yellow-200 rounded-lg p-4 bg-yellow-50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Custom Design Applied</span>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      className="text-xs"
                    >
                      <RotateCcw className="w-3 h-3 mr-1" />
                      Replace
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={removeCustomDesign}
                      className="text-xs text-red-600 hover:text-red-700 bg-transparent"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Remove
                    </Button>
                  </div>
                </div>
                {designFile && <p className="text-xs text-gray-600">{designFile.name}</p>}
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </div>
            )}
          </div>

          {/* Color Selection - Disabled when custom design is active */}
          <div className="space-y-3">
            <label className={`text-sm font-medium ${customDesign ? "text-gray-400" : "text-gray-700"}`}>
              Color {customDesign && "(Disabled with custom design)"}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {colors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => !customDesign && setSelectedColor(color)}
                  disabled={!!customDesign}
                  className={`p-3 rounded-lg border-2 transition-all relative overflow-hidden ${
                    selectedColor.name === color.name && !customDesign
                      ? "border-yellow-500 shadow-lg ring-2 ring-yellow-200"
                      : "border-gray-300 hover:border-gray-400"
                  } ${customDesign ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                  style={{ backgroundColor: color.value }}
                >
                  <span
                    className={`text-xs font-medium drop-shadow-lg relative z-10 ${
                      color.value === "#FFFFFF" || color.value === "#F3F4F6" ? "text-gray-700" : "text-white"
                    }`}
                  >
                    {color.name}
                  </span>
                  {selectedColor.name === color.name && !customDesign && (
                    <div className="absolute inset-0 bg-yellow-400 opacity-20 animate-pulse" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Material Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Material</label>
            <div className="space-y-2">
              {materials.map((material) => (
                <button
                  key={material.name}
                  onClick={() => setSelectedMaterial(material)}
                  className={`w-full p-3 rounded-lg border text-left transition-all ${
                    selectedMaterial.name === material.name
                      ? "border-yellow-400 bg-yellow-50"
                      : "border-gray-300 hover:border-gray-400 bg-white"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="text-gray-900 font-medium">{material.name}</span>
                      {material.value === "metal" && <span className="text-xs text-gray-500">✨ Shiny</span>}
                      {material.value === "wood" && <span className="text-xs text-gray-500">🌳 Textured</span>}
                    </div>
                    {material.price > 0 && (
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                        +${material.price}
                      </Badge>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Thickness Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Thickness</label>
            <div className="space-y-2">
              {thicknesses.map((thickness) => (
                <button
                  key={thickness.name}
                  onClick={() => setSelectedThickness(thickness)}
                  className={`w-full p-3 rounded-lg border text-left transition-all ${
                    selectedThickness.name === thickness.name
                      ? "border-yellow-400 bg-yellow-50"
                      : "border-gray-300 hover:border-gray-400 bg-white"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-gray-900 font-medium">{thickness.name}</span>
                    {thickness.price > 0 && (
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                        +${thickness.price}
                      </Badge>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Engraving */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Custom Engraving (+$3)</label>
            <input
              type="text"
              placeholder="Enter text (max 20 characters)"
              maxLength={20}
              value={engraving}
              onChange={(e) => setEngraving(e.target.value)}
              className="w-full p-3 rounded-lg bg-white border border-gray-300 text-gray-900 placeholder-gray-500 focus:border-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-200"
            />
          </div>

          <Separator className="bg-gray-200" />

          {/* Price and Add to Cart */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold text-gray-900">Total Price:</span>
              <span className="text-2xl font-bold text-yellow-600">${totalPrice.toFixed(2)}</span>
            </div>
            {customDesign && <p className="text-xs text-gray-600">Includes $8.00 custom design fee</p>}
            <Button
              onClick={handleAddToCart}
              className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold"
              size="lg"
            >
              Add to Cart
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
