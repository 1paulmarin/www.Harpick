import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Navigation from "./components/Navigation"
import { CartProvider } from "./components/CartProvider"
import { LanguageProvider } from "./contexts/LanguageContext"
import { CurrencyProvider } from "./contexts/CurrencyContext"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Harpick - Custom Guitar Picks & Accessories",
  description:
    "Design and order custom guitar picks with our 3D customizer. Premium materials, fast shipping, and professional quality.",
  keywords: "guitar picks, custom guitar picks, personalized picks, guitar accessories, harpick",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <LanguageProvider>
          <CurrencyProvider>
            <CartProvider>
              <Navigation />
              <main>{children}</main>
            </CartProvider>
          </CurrencyProvider>
        </LanguageProvider>
      </body>
    </html>
  )
}
