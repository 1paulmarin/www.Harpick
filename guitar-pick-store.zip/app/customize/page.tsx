"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useCart } from "../components/CartProvider"
import { useLanguage } from "../contexts/LanguageContext"
import { useCurrency } from "../contexts/CurrencyContext"
import { Upload, X, RotateCcw, ArrowLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

function GuitarPickDisplay({
  color = "#FFFFFF",
  material = "standard",
  customDesign = null,
  showingSide = "front",
  frontDesign = null,
  backDesign = null,
  rotation = 0,
  scale = 1,
}: {
  color?: string
  material?: string
  customDesign?: string | null
  showingSide?: "front" | "back"
  frontDesign?: string | null
  backDesign?: string | null
  rotation?: number
  scale?: number
}) {
  const getColorOverlay = (color: string, material: string) => {
    if (color === "#FFFFFF") return "none"

    const baseFilter = `hue-rotate(${getHueRotation(color)}deg) saturate(1.8) brightness(0.9)`

    switch (material) {
      case "metal":
        return `${baseFilter} contrast(1.2) brightness(1.1)`
      case "wood":
        return `${baseFilter} sepia(0.3) contrast(0.9) brightness(0.8)`
      default:
        return baseFilter
    }
  }

  const getColorStyle = (color: string, material: string) => {
    const currentDesign = showingSide === "front" ? frontDesign : backDesign
    if (color === "#FFFFFF" || currentDesign) {
      return {}
    }

    return {
      filter: getColorOverlay(color, material),
      transition: "filter 0.3s ease-in-out",
    }
  }

  const currentDesign = showingSide === "front" ? frontDesign : backDesign

  return (
    <div className="flex justify-center items-center h-full">
      <div
        className="relative transition-transform duration-200"
        style={{
          transform: `rotateY(${rotation}deg) scale(${scale})`,
        }}
      >
        {/* Base white pick image */}
        <Image
          src="/pana_alba-removebg-preview.png"
          alt="Guitar Pick"
          width={200}
          height={200}
          className="object-contain transition-all duration-300"
          style={currentDesign ? {} : getColorStyle(color, material)}
        />

        {/* Custom Design Overlay */}
        {currentDesign && (
          <div
            className="absolute inset-0 transition-opacity duration-300"
            style={{
              backgroundImage: `url(${currentDesign})`,
              backgroundSize: "contain",
              backgroundRepeat: "no-repeat",
              backgroundPosition: "center",
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
              mixBlendMode: "multiply",
            }}
          />
        )}

        {/* Color overlay for non-white colors (only if no custom design) */}
        {color !== "#FFFFFF" && !currentDesign && (
          <div
            className="absolute inset-0 mix-blend-multiply opacity-60 transition-opacity duration-300"
            style={{
              backgroundColor: color,
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
            }}
          />
        )}

        {/* Material-specific effects (only if no custom design) */}
        {!currentDesign && material === "metal" && (
          <div
            className="absolute inset-0 opacity-20 transition-opacity duration-300"
            style={{
              background: "linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.8) 50%, transparent 70%)",
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
            }}
          />
        )}

        {!currentDesign && material === "wood" && (
          <div
            className="absolute inset-0 opacity-15 transition-opacity duration-300"
            style={{
              background:
                "repeating-linear-gradient(90deg, rgba(139,69,19,0.3) 0px, rgba(160,82,45,0.3) 2px, rgba(139,69,19,0.3) 4px)",
              maskImage: "url('/pana_alba-removebg-preview.png')",
              maskSize: "contain",
              maskRepeat: "no-repeat",
              maskPosition: "center",
              WebkitMaskImage: "url('/pana_alba-removebg-preview.png')",
              WebkitMaskSize: "contain",
              WebkitMaskRepeat: "no-repeat",
              WebkitMaskPosition: "center",
            }}
          />
        )}

        {/* Side indicator */}
        <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2">
          <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-600">
            {showingSide === "front" ? "Front Side" : "Back Side"}
          </Badge>
        </div>
      </div>
    </div>
  )
}

function getHueRotation(color: string): number {
  const colorMap: { [key: string]: number } = {
    "#EAB308": 45, // Yellow
    "#3B82F6": 220, // Blue
    "#EF4444": 0, // Red
    "#10B981": 140, // Green
    "#F3F4F6": 0, // Light Gray
    "#FFFFFF": 0, // White
    "#8B5CF6": 280, // Purple
    "#F97316": 25, // Orange
    "#EC4899": 320, // Pink
    "#000000": 0, // Black
  }
  return colorMap[color] || 0
}

const colors = [
  { name: "White", value: "#FFFFFF" },
  { name: "Yellow", value: "#EAB308" },
  { name: "Blue", value: "#3B82F6" },
  { name: "Red", value: "#EF4444" },
  { name: "Green", value: "#10B981" },
  { name: "Purple", value: "#8B5CF6" },
  { name: "Orange", value: "#F97316" },
  { name: "Pink", value: "#EC4899" },
  { name: "Black", value: "#000000" },
]

const materials = [
  { name: "Standard", value: "standard", price: 0 },
  { name: "Metal", value: "metal", price: 5 },
  { name: "Wood", value: "wood", price: 3 },
]

const thicknesses = [
  { name: "Thin (0.5mm)", value: "thin", price: 0 },
  { name: "Medium (0.7mm)", value: "medium", price: 0 },
  { name: "Heavy (1.0mm)", value: "heavy", price: 1 },
]

const printOptions = [
  { name: "One-Sided", value: "one-sided", price: 0, description: "Design on front only" },
  { name: "Two-Sided", value: "two-sided", price: 4, description: "Different designs on both sides" },
]

export default function CustomizePage() {
  const { t } = useLanguage()
  const { formatPrice } = useCurrency()
  const [selectedColor, setSelectedColor] = useState(colors[0])
  const [selectedMaterial, setSelectedMaterial] = useState(materials[0])
  const [selectedThickness, setSelectedThickness] = useState(thicknesses[1])
  const [selectedPrintOption, setSelectedPrintOption] = useState(printOptions[0])
  const [engraving, setEngraving] = useState("")
  const [frontDesign, setFrontDesign] = useState<string | null>(null)
  const [backDesign, setBackDesign] = useState<string | null>(null)
  const [frontDesignFile, setFrontDesignFile] = useState<File | null>(null)
  const [backDesignFile, setBackDesignFile] = useState<File | null>(null)
  const [showingSide, setShowingSide] = useState<"front" | "back">("front")
  const frontFileInputRef = useRef<HTMLInputElement>(null)
  const backFileInputRef = useRef<HTMLInputElement>(null)
  const { addToCart } = useCart()

  const [rotation, setRotation] = useState(0)
  const [zoom, setZoom] = useState(1)

  const basePrice = 12.99
  const frontDesignPrice = frontDesign ? 8 : 0
  const backDesignPrice = backDesign && selectedPrintOption.value === "two-sided" ? 8 : 0
  const totalPrice =
    basePrice +
    selectedMaterial.price +
    selectedThickness.price +
    selectedPrintOption.price +
    (engraving ? 3 : 0) +
    frontDesignPrice +
    backDesignPrice

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, side: "front" | "back") => {
    const file = event.target.files?.[0]
    if (file) {
      if (!file.type.startsWith("image/")) {
        alert("Please upload an image file (PNG, JPG, GIF, etc.)")
        return
      }

      if (file.size > 5 * 1024 * 1024) {
        alert("File size must be less than 5MB")
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        if (side === "front") {
          setFrontDesign(e.target?.result as string)
          setFrontDesignFile(file)
        } else {
          setBackDesign(e.target?.result as string)
          setBackDesignFile(file)
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const removeDesign = (side: "front" | "back") => {
    if (side === "front") {
      setFrontDesign(null)
      setFrontDesignFile(null)
      if (frontFileInputRef.current) {
        frontFileInputRef.current.value = ""
      }
    } else {
      setBackDesign(null)
      setBackDesignFile(null)
      if (backFileInputRef.current) {
        backFileInputRef.current.value = ""
      }
    }
  }

  const handleAddToCart = () => {
    const customPick = {
      id: `custom-${Date.now()}`,
      name: "Custom Guitar Pick",
      price: totalPrice,
      image: "/pana_alba-removebg-preview.png",
      customization: {
        color: frontDesign || backDesign ? "Custom Design" : selectedColor.name,
        material: selectedMaterial.name,
        thickness: selectedThickness.name,
        printOption: selectedPrintOption.name,
        engraving: engraving || "None",
        frontDesign: frontDesign ? "Yes" : "No",
        backDesign: backDesign ? "Yes" : "No",
      },
    }
    addToCart(customPick)
  }

  const hasCustomDesigns = frontDesign || backDesign

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link
            href="/"
            className="inline-flex items-center text-yellow-600 hover:text-yellow-700 mb-4 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {t("customize.back")}
          </Link>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{t("customize.title")}</h1>
          <p className="text-xl text-gray-600">{t("customize.subtitle")}</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Guitar Pick Display */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-bold text-gray-900">{t("customize.preview")}</h3>
              {selectedPrintOption.value === "two-sided" && (
                <div className="flex gap-2">
                  <Button
                    variant={showingSide === "front" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setShowingSide("front")}
                    className={
                      showingSide === "front"
                        ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                        : "border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                    }
                  >
                    {t("customize.front")}
                  </Button>
                  <Button
                    variant={showingSide === "back" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setShowingSide("back")}
                    className={
                      showingSide === "back"
                        ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                        : "border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                    }
                  >
                    {t("customize.back")}
                  </Button>
                </div>
              )}
            </div>

            <div className="h-80 flex items-center justify-center">
              <GuitarPickDisplay
                color={selectedColor.value}
                material={selectedMaterial.value}
                showingSide={showingSide}
                frontDesign={frontDesign}
                backDesign={backDesign}
                rotation={rotation}
                scale={zoom}
              />
            </div>

            {/* Control Panel */}
            <div className="space-y-4 bg-white rounded-lg p-4 border border-gray-200">
              {/* Rotation Control */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">{t("customize.rotation")}</label>
                  <span className="text-sm text-gray-500">{rotation}°</span>
                </div>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={rotation}
                  onChange={(e) => setRotation(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  style={{
                    background: `linear-gradient(to right, #EAB308 0%, #EAB308 ${((rotation + 180) / 360) * 100}%, #e5e7eb ${((rotation + 180) / 360) * 100}%, #e5e7eb 100%)`,
                  }}
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>-180°</span>
                  <span>0°</span>
                  <span>180°</span>
                </div>
              </div>

              {/* Zoom Control */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">{t("customize.zoom")}</label>
                  <span className="text-sm text-gray-500">{Math.round(zoom * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={zoom}
                  onChange={(e) => setZoom(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  style={{
                    background: `linear-gradient(to right, #EAB308 0%, #EAB308 ${((zoom - 0.5) / 1.5) * 100}%, #e5e7eb ${((zoom - 0.5) / 1.5) * 100}%, #e5e7eb 100%)`,
                  }}
                />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>50%</span>
                  <span>100%</span>
                  <span>200%</span>
                </div>
              </div>

              {/* Reset Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setRotation(0)
                  setZoom(1)
                }}
                className="w-full text-gray-600 border-gray-300 hover:bg-gray-50"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                {t("customize.reset")}
              </Button>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-500">{t("customize.controls")}</p>
              {selectedPrintOption.value === "two-sided" && (
                <p className="text-sm text-gray-500">{t("customize.switch")}</p>
              )}
            </div>
          </div>

          {/* Customization Options */}
          <Card className="bg-white/90 backdrop-blur-sm border-yellow-200/50 shadow-lg">
            <CardHeader>
              <CardTitle className="text-gray-900">{t("customize.options")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Print Options */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">{t("print.title")}</label>
                <div className="space-y-2">
                  {printOptions.map((option) => (
                    <button
                      key={option.name}
                      onClick={() => {
                        setSelectedPrintOption(option)
                        if (option.value === "one-sided") {
                          setBackDesign(null)
                          setBackDesignFile(null)
                          setShowingSide("front")
                        }
                      }}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        selectedPrintOption.name === option.name
                          ? "border-yellow-400 bg-yellow-50"
                          : "border-gray-300 hover:border-gray-400 bg-white"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <span className="text-gray-900 font-medium">
                            {t(option.value === "one-sided" ? "print.oneSided" : "print.twoSided")}
                          </span>
                          <p className="text-xs text-gray-500">
                            {t(option.value === "one-sided" ? "print.oneSidedDesc" : "print.twoSidedDesc")}
                          </p>
                        </div>
                        {option.price > 0 && (
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                            +{formatPrice(option.price)}
                          </Badge>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Front Design Upload */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">
                  {t("design.front")} (+{formatPrice(8)}){" "}
                  {selectedPrintOption.value === "two-sided" && showingSide === "front" && `- ${t("design.viewing")}`}
                </label>

                {!frontDesign ? (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-yellow-400 transition-colors">
                    <input
                      ref={frontFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, "front")}
                      className="hidden"
                    />
                    <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600 mb-2">{t("design.upload")}</p>
                    <p className="text-xs text-gray-500 mb-3">{t("design.fileTypes")}</p>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => frontFileInputRef.current?.click()}
                      className="border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {t("design.choose")}
                    </Button>
                  </div>
                ) : (
                  <div className="border border-yellow-200 rounded-lg p-4 bg-yellow-50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">{t("design.applied")}</span>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => frontFileInputRef.current?.click()}
                          className="text-xs"
                        >
                          <RotateCcw className="w-3 h-3 mr-1" />
                          {t("design.replace")}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeDesign("front")}
                          className="text-xs text-red-600 hover:text-red-700 bg-transparent"
                        >
                          <X className="w-3 h-3 mr-1" />
                          {t("design.remove")}
                        </Button>
                      </div>
                    </div>
                    {frontDesignFile && <p className="text-xs text-gray-600">{frontDesignFile.name}</p>}
                    <input
                      ref={frontFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, "front")}
                      className="hidden"
                    />
                  </div>
                )}
              </div>

              {/* Back Design Upload - Only show if two-sided is selected */}
              {selectedPrintOption.value === "two-sided" && (
                <div className="space-y-3">
                  <label className="text-sm font-medium text-gray-700">
                    {t("design.back")} (+{formatPrice(8)}) {showingSide === "back" && `- ${t("design.viewing")}`}
                  </label>

                  {!backDesign ? (
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-yellow-400 transition-colors">
                      <input
                        ref={backFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e, "back")}
                        className="hidden"
                      />
                      <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm text-gray-600 mb-2">{t("design.uploadBack")}</p>
                      <p className="text-xs text-gray-500 mb-3">{t("design.fileTypes")}</p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => backFileInputRef.current?.click()}
                        className="border-yellow-500 text-yellow-600 hover:bg-yellow-50"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        {t("design.choose")}
                      </Button>
                    </div>
                  ) : (
                    <div className="border border-yellow-200 rounded-lg p-4 bg-yellow-50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-700">{t("design.appliedBack")}</span>
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => backFileInputRef.current?.click()}
                            className="text-xs"
                          >
                            <RotateCcw className="w-3 h-3 mr-1" />
                            {t("design.replace")}
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeDesign("back")}
                            className="text-xs text-red-600 hover:text-red-700 bg-transparent"
                          >
                            <X className="w-3 h-3 mr-1" />
                            {t("design.remove")}
                          </Button>
                        </div>
                      </div>
                      {backDesignFile && <p className="text-xs text-gray-600">{backDesignFile.name}</p>}
                      <input
                        ref={backFileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e, "back")}
                        className="hidden"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Color Selection - Disabled when custom design is active */}
              <div className="space-y-3">
                <label className={`text-sm font-medium ${hasCustomDesigns ? "text-gray-400" : "text-gray-700"}`}>
                  {t("color.title")} {hasCustomDesigns && t("color.disabled")}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {colors.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => !hasCustomDesigns && setSelectedColor(color)}
                      disabled={hasCustomDesigns}
                      className={`p-3 rounded-lg border-2 transition-all relative overflow-hidden ${
                        selectedColor.name === color.name && !hasCustomDesigns
                          ? "border-yellow-500 shadow-lg ring-2 ring-yellow-200"
                          : "border-gray-300 hover:border-gray-400"
                      } ${hasCustomDesigns ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}`}
                      style={{ backgroundColor: color.value }}
                    >
                      <span
                        className={`text-xs font-medium drop-shadow-lg relative z-10 ${
                          color.value === "#FFFFFF" || color.value === "#F3F4F6" ? "text-gray-700" : "text-white"
                        }`}
                      >
                        {t(`color.${color.name.toLowerCase()}`)}
                      </span>
                      {selectedColor.name === color.name && !hasCustomDesigns && (
                        <div className="absolute inset-0 bg-yellow-400 opacity-20 animate-pulse" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Material Selection */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">{t("material.title")}</label>
                <div className="space-y-2">
                  {materials.map((material) => (
                    <button
                      key={material.name}
                      onClick={() => setSelectedMaterial(material)}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        selectedMaterial.name === material.name
                          ? "border-yellow-400 bg-yellow-50"
                          : "border-gray-300 hover:border-gray-400 bg-white"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="text-gray-900 font-medium">{t(`material.${material.value}`)}</span>
                          {material.value === "metal" && (
                            <span className="text-xs text-gray-500">{t("material.shiny")}</span>
                          )}
                          {material.value === "wood" && (
                            <span className="text-xs text-gray-500">{t("material.textured")}</span>
                          )}
                        </div>
                        {material.price > 0 && (
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                            +{formatPrice(material.price)}
                          </Badge>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Thickness Selection */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">{t("thickness.title")}</label>
                <div className="space-y-2">
                  {thicknesses.map((thickness) => (
                    <button
                      key={thickness.name}
                      onClick={() => setSelectedThickness(thickness)}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        selectedThickness.name === thickness.name
                          ? "border-yellow-400 bg-yellow-50"
                          : "border-gray-300 hover:border-gray-400 bg-white"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-gray-900 font-medium">{t(`thickness.${thickness.value}`)}</span>
                        {thickness.price > 0 && (
                          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                            +{formatPrice(thickness.price)}
                          </Badge>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Engraving */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-700">
                  {t("engraving.title").replace("+$3", `+${formatPrice(3)}`)}
                </label>
                <input
                  type="text"
                  placeholder={t("engraving.placeholder")}
                  maxLength={20}
                  value={engraving}
                  onChange={(e) => setEngraving(e.target.value)}
                  className="w-full p-3 rounded-lg bg-white border border-gray-300 text-gray-900 placeholder-gray-500 focus:border-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-200"
                />
              </div>

              <Separator className="bg-gray-200" />

              {/* Price Breakdown and Add to Cart */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{t("price.base")}</span>
                    <span>{formatPrice(basePrice)}</span>
                  </div>
                  {selectedMaterial.price > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>
                        {t(`material.${selectedMaterial.value}`)} {t("price.material").replace(":", "")}
                      </span>
                      <span>+{formatPrice(selectedMaterial.price)}</span>
                    </div>
                  )}
                  {selectedThickness.price > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>{t(`thickness.${selectedThickness.value}`)}:</span>
                      <span>+{formatPrice(selectedThickness.price)}</span>
                    </div>
                  )}
                  {selectedPrintOption.price > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>{t(selectedPrintOption.value === "one-sided" ? "print.oneSided" : "print.twoSided")}:</span>
                      <span>+{formatPrice(selectedPrintOption.price)}</span>
                    </div>
                  )}
                  {frontDesignPrice > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>{t("price.frontDesign")}</span>
                      <span>+{formatPrice(frontDesignPrice)}</span>
                    </div>
                  )}
                  {backDesignPrice > 0 && (
                    <div className="flex justify-between text-sm">
                      <span>{t("price.backDesign")}</span>
                      <span>+{formatPrice(backDesignPrice)}</span>
                    </div>
                  )}
                  {engraving && (
                    <div className="flex justify-between text-sm">
                      <span>{t("price.engraving")}</span>
                      <span>+{formatPrice(3)}</span>
                    </div>
                  )}
                </div>

                <Separator className="bg-gray-200" />

                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-gray-900">{t("price.total")}</span>
                  <span className="text-2xl font-bold text-yellow-600">{formatPrice(totalPrice)}</span>
                </div>

                <Button
                  onClick={handleAddToCart}
                  className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold"
                  size="lg"
                >
                  {t("price.addToCart")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
