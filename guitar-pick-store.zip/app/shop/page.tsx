"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Search, Filter } from "lucide-react"
import { useCart } from "../components/CartProvider"

const products = [
  {
    id: "classic-set",
    name: "Classic Celluloid Pick Set",
    price: 8.99,
    originalPrice: 12.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "picks",
    material: "celluloid",
    badge: "Best Seller",
    description: "Traditional celluloid picks in assorted colors and thicknesses",
  },
  {
    id: "metal-thunder",
    name: "Metal Thunder Picks",
    price: 15.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "picks",
    material: "metal",
    badge: "New",
    description: "Heavy-duty metal picks for aggressive playing styles",
  },
  {
    id: "wooden-acoustic",
    name: "Wooden Acoustic Set",
    price: 19.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "picks",
    material: "wood",
    badge: "Eco-Friendly",
    description: "Handcrafted wooden picks perfect for acoustic guitars",
  },
  {
    id: "glow-dark",
    name: "Glow-in-Dark Pack",
    price: 11.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "picks",
    material: "plastic",
    badge: "Popular",
    description: "Fun glow-in-the-dark picks for night performances",
  },
  {
    id: "pick-punch",
    name: "DIY Pick Punch Tool",
    price: 39.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "accessories",
    material: "metal",
    description: "Create your own picks from any material",
  },
  {
    id: "display-case-transparent",
    name: "A4 Transparent Display Case",
    price: 29.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "accessories",
    material: "acrylic",
    description: "Crystal clear A4-sized display case for showcasing your pick collection",
  },
  {
    id: "display-case-white",
    name: "A4 White Display Case",
    price: 32.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "accessories",
    material: "plastic",
    description: "Elegant white A4-sized display case with solid color finish",
  },
  {
    id: "display-case-wood",
    name: "A4 Wooden Display Case",
    price: 49.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "accessories",
    material: "wood",
    description: "Premium wooden A4-sized display case with natural wood finish",
  },
  {
    id: "display-case-metal",
    name: "A4 Metal Display Case",
    price: 59.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "accessories",
    material: "metal",
    description: "Professional metal A4-sized display case with brushed finish",
  },
  {
    id: "jazz-picks",
    name: "Jazz Master Picks",
    price: 13.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "picks",
    material: "delrin",
    description: "Precision picks designed for jazz guitarists",
  },
  {
    id: "bass-picks",
    name: "Heavy Bass Pick Set",
    price: 16.99,
    image: "/placeholder.svg?height=200&width=200",
    category: "picks",
    material: "nylon",
    description: "Extra thick picks designed for bass guitar",
  },
]

export default function ShopPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("featured")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([])
  const { addToCart } = useCart()

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(product.category)
    const matchesMaterial = selectedMaterials.length === 0 || selectedMaterials.includes(product.material)

    return matchesSearch && matchesCategory && matchesMaterial
  })

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "name":
        return a.name.localeCompare(b.name)
      default:
        return 0
    }
  })

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category])
    } else {
      setSelectedCategories(selectedCategories.filter((c) => c !== category))
    }
  }

  const handleMaterialChange = (material: string, checked: boolean) => {
    if (checked) {
      setSelectedMaterials([...selectedMaterials, material])
    } else {
      setSelectedMaterials(selectedMaterials.filter((m) => m !== material))
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Shop Guitar Picks & Accessories</h1>
          <p className="text-xl text-gray-600">
            Discover our complete collection of premium guitar picks and accessories
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Filter className="w-5 h-5" />
                  <h2 className="text-lg font-semibold">Filters</h2>
                </div>

                {/* Search */}
                <div className="mb-6">
                  <Label htmlFor="search" className="text-sm font-medium mb-2 block">
                    Search Products
                  </Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="search"
                      placeholder="Search picks..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Category Filter */}
                <div className="mb-6">
                  <Label className="text-sm font-medium mb-3 block">Category</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="picks"
                        checked={selectedCategories.includes("picks")}
                        onCheckedChange={(checked) => handleCategoryChange("picks", checked as boolean)}
                      />
                      <Label htmlFor="picks" className="text-sm">
                        Guitar Picks
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="accessories"
                        checked={selectedCategories.includes("accessories")}
                        onCheckedChange={(checked) => handleCategoryChange("accessories", checked as boolean)}
                      />
                      <Label htmlFor="accessories" className="text-sm">
                        Accessories
                      </Label>
                    </div>
                  </div>
                </div>

                {/* Material Filter */}
                <div className="mb-6">
                  <Label className="text-sm font-medium mb-3 block">Material</Label>
                  <div className="space-y-2">
                    {["celluloid", "metal", "wood", "plastic", "acrylic"].map((material) => (
                      <div key={material} className="flex items-center space-x-2">
                        <Checkbox
                          id={material}
                          checked={selectedMaterials.includes(material)}
                          onCheckedChange={(checked) => handleMaterialChange(material, checked as boolean)}
                        />
                        <Label htmlFor={material} className="text-sm capitalize">
                          {material}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Products Grid */}
          <div className="lg:col-span-3">
            {/* Sort and Results */}
            <div className="flex justify-between items-center mb-6">
              <p className="text-gray-600">
                Showing {sortedProducts.length} of {products.length} products
              </p>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="name">Name: A to Z</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Products Grid */}
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
              {sortedProducts.map((product) => (
                <Card key={product.id} className="group hover:shadow-xl transition-all duration-300 overflow-hidden">
                  <div className="relative">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={200}
                      height={200}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {product.badge && (
                      <Badge className="absolute top-3 left-3 bg-yellow-500 hover:bg-yellow-600 text-black">
                        {product.badge}
                      </Badge>
                    )}
                  </div>

                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-yellow-600 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-3">{product.description}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-yellow-600">${product.price}</span>
                      {product.originalPrice && (
                        <span className="text-sm text-gray-500 line-through">${product.originalPrice}</span>
                      )}
                    </div>
                  </CardContent>

                  <CardFooter className="p-6 pt-0">
                    <Button
                      className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-semibold"
                      onClick={() =>
                        addToCart({
                          id: product.id,
                          name: product.name,
                          price: product.price,
                          image: product.image,
                        })
                      }
                    >
                      Add to Cart
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>

            {sortedProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">No products found matching your criteria.</p>
                <Button
                  variant="outline"
                  className="mt-4 bg-transparent"
                  onClick={() => {
                    setSearchTerm("")
                    setSelectedCategories([])
                    setSelectedMaterials([])
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
