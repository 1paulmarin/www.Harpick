"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Guitar, Palette, Truck, Shield } from "lucide-react"
import { useLanguage } from "./contexts/LanguageContext"
import FeaturedProducts from "./components/FeaturedProducts"

export default function HomePage() {
  const { t } = useLanguage()

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 via-white to-gray-100 text-gray-900">
        <div className="container mx-auto px-4 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="bg-yellow-500/10 text-yellow-700 border-yellow-500/30">
                  {t("home.hero.badge")}
                </Badge>
                <h1 className="text-5xl lg:text-7xl font-bold leading-tight text-gray-900">
                  {t("home.hero.title").split(" ").slice(0, 2).join(" ")}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-500 to-yellow-600">
                    {" "}
                    {t("home.hero.title").split(" ").slice(2).join(" ")}
                  </span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">{t("home.hero.description")}</p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold"
                  asChild
                >
                  <Link href="/customize">{t("home.hero.start")}</Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50 bg-white"
                  asChild
                >
                  <Link href="/shop">{t("home.hero.browse")}</Link>
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <Palette className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                  <p className="text-sm text-gray-600">{t("home.hero.colors")}</p>
                </div>
                <div className="text-center">
                  <Guitar className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                  <p className="text-sm text-gray-600">{t("home.hero.materials")}</p>
                </div>
                <div className="text-center">
                  <Truck className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                  <p className="text-sm text-gray-600">{t("home.hero.shipping")}</p>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-yellow-50/80 to-yellow-100/80 rounded-3xl p-8 backdrop-blur-sm border border-yellow-200/50 shadow-lg">
                <div className="text-center space-y-6">
                  <h3 className="text-2xl font-bold text-gray-900">{t("customizer.title")}</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 text-gray-700">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <span>{t("customizer.upload")}</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-700">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <span>{t("customizer.printing")}</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-700">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <span>{t("customizer.preview")}</span>
                    </div>
                    <div className="flex items-center gap-3 text-gray-700">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <span>{t("customizer.materials")}</span>
                    </div>
                  </div>
                  <Button
                    className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold"
                    asChild
                  >
                    <Link href="/customize">{t("customizer.try")}</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">{t("features.title")}</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">{t("features.subtitle")}</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                  <Guitar className="w-8 h-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold">{t("features.materials.title")}</h3>
                <p className="text-gray-600">{t("features.materials.desc")}</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                  <Palette className="w-8 h-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold">{t("features.design.title")}</h3>
                <p className="text-gray-600">{t("features.design.desc")}</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                  <Truck className="w-8 h-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold">{t("features.delivery.title")}</h3>
                <p className="text-gray-600">{t("features.delivery.desc")}</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="space-y-4">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                  <Shield className="w-8 h-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-semibold">{t("features.guarantee.title")}</h3>
                <p className="text-gray-600">{t("features.guarantee.desc")}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <FeaturedProducts />

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">{t("cta.title")}</h2>
          <p className="text-xl mb-8 opacity-90">{t("cta.subtitle")}</p>
          <Button
            size="lg"
            variant="secondary"
            className="bg-white text-yellow-600 hover:bg-gray-50 font-semibold"
            asChild
          >
            <Link href="/customize">{t("cta.button")}</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
