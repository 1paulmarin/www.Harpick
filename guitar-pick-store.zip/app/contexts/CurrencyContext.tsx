"use client"

import { createContext, useContext, type ReactNode } from "react"
import { useLanguage, type Language } from "./LanguageContext"

interface CurrencyInfo {
  code: string
  symbol: string
  rate: number // Conversion rate from USD
  position: "before" | "after" // Symbol position
}

const currencies: Record<Language, CurrencyInfo> = {
  en: { code: "EUR", symbol: "€", rate: 0.92, position: "before" }, // English - Euros
  ro: { code: "RON", symbol: "lei", rate: 4.65, position: "after" }, // Romanian - Lei
  ru: { code: "RUB", symbol: "₽", rate: 92.5, position: "after" }, // Russian - Rubles
  zh: { code: "CNY", symbol: "¥", rate: 7.25, position: "before" }, // Chinese - Yuan
}

interface CurrencyContextType {
  formatPrice: (usdPrice: number) => string
  getCurrency: () => CurrencyInfo
}

const CurrencyContext = createContext<CurrencyContextType | null>(null)

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const { language } = useLanguage()

  const getCurrency = (): CurrencyInfo => {
    return currencies[language]
  }

  const formatPrice = (usdPrice: number): string => {
    const currency = getCurrency()
    const convertedPrice = usdPrice * currency.rate

    // Round to appropriate decimal places based on currency
    let roundedPrice: string
    if (currency.code === "RON" || currency.code === "RUB") {
      // Romanian Lei and Russian Rubles - round to whole numbers for larger amounts
      if (convertedPrice >= 10) {
        roundedPrice = Math.round(convertedPrice).toString()
      } else {
        roundedPrice = convertedPrice.toFixed(2)
      }
    } else {
      // Euros and Yuan - 2 decimal places
      roundedPrice = convertedPrice.toFixed(2)
    }

    // Format with symbol position
    if (currency.position === "before") {
      return `${currency.symbol}${roundedPrice}`
    } else {
      return `${roundedPrice} ${currency.symbol}`
    }
  }

  return <CurrencyContext.Provider value={{ formatPrice, getCurrency }}>{children}</CurrencyContext.Provider>
}

export function useCurrency() {
  const context = useContext(CurrencyContext)
  if (!context) {
    throw new Error("useCurrency must be used within a CurrencyProvider")
  }
  return context
}
