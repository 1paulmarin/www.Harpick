"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type Language = "en" | "ro" | "ru" | "zh"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | null>(null)

const translations = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.shop": "Shop",
    "nav.customize": "Customize",
    "nav.about": "About",
    "nav.contact": "Contact",

    // Homepage
    "home.hero.badge": "Custom Guitar Picks",
    "home.hero.title": "Craft Your Perfect Pick",
    "home.hero.description":
      "Design custom guitar picks with our advanced 3D customizer. Choose materials, colors, and engravings to create picks that match your style and sound.",
    "home.hero.start": "Start Customizing",
    "home.hero.browse": "Browse Shop",
    "home.hero.colors": "Custom Colors",
    "home.hero.materials": "Premium Materials",
    "home.hero.shipping": "Fast Shipping",

    // Features
    "features.title": "Why Choose Our Picks?",
    "features.subtitle": "Professional-grade guitar picks designed for musicians who demand the best",
    "features.materials.title": "Premium Materials",
    "features.materials.desc": "High-quality materials including celluloid, delrin, and exotic woods",
    "features.design.title": "Custom Design",
    "features.design.desc": "Personalize with colors, patterns, and custom engravings",
    "features.delivery.title": "Fast Delivery",
    "features.delivery.desc": "Quick turnaround with express shipping options available",
    "features.guarantee.title": "Quality Guarantee",
    "features.guarantee.desc": "30-day money-back guarantee on all custom picks",

    // Customizer
    "customizer.title": "Advanced Customizer",
    "customizer.upload": "Upload custom designs",
    "customizer.printing": "One-sided or two-sided printing",
    "customizer.preview": "Real-time 3D preview",
    "customizer.materials": "Multiple materials & colors",
    "customizer.try": "Try the Designer",

    // CTA
    "cta.title": "Ready to Create Your Perfect Pick?",
    "cta.subtitle": "Join thousands of musicians who trust our custom guitar picks",
    "cta.button": "Start Customizing Now",

    // Customize Page
    "customize.back": "Back to Home",
    "customize.title": "Custom Guitar Pick Designer",
    "customize.subtitle": "Create your perfect guitar pick with our advanced customization tools",
    "customize.preview": "Pick Preview",
    "customize.front": "Front",
    "customize.back": "Back",
    "customize.rotation": "Rotation",
    "customize.zoom": "Zoom",
    "customize.reset": "Reset View",
    "customize.controls": "Use the controls above to rotate and zoom the pick",
    "customize.switch": "Use the Front/Back buttons to switch sides",
    "customize.options": "Customize Your Pick",

    // Print Options
    "print.title": "Print Options",
    "print.oneSided": "One-Sided",
    "print.twoSided": "Two-Sided",
    "print.oneSidedDesc": "Design on front only",
    "print.twoSidedDesc": "Different designs on both sides",

    // Design Upload
    "design.front": "Front Design",
    "design.back": "Back Design",
    "design.viewing": "Currently Viewing",
    "design.upload": "Upload front design",
    "design.uploadBack": "Upload back design",
    "design.fileTypes": "PNG, JPG, GIF up to 5MB",
    "design.choose": "Choose File",
    "design.applied": "Front Design Applied",
    "design.appliedBack": "Back Design Applied",
    "design.replace": "Replace",
    "design.remove": "Remove",

    // Colors
    "color.title": "Color",
    "color.disabled": "(Disabled with custom design)",
    "color.white": "White",
    "color.yellow": "Yellow",
    "color.blue": "Blue",
    "color.red": "Red",
    "color.green": "Green",
    "color.purple": "Purple",
    "color.orange": "Orange",
    "color.pink": "Pink",
    "color.black": "Black",

    // Materials
    "material.title": "Material",
    "material.standard": "Standard",
    "material.metal": "Metal",
    "material.wood": "Wood",
    "material.shiny": "✨ Shiny",
    "material.textured": "🌳 Textured",

    // Thickness
    "thickness.title": "Thickness",
    "thickness.thin": "Thin (0.5mm)",
    "thickness.medium": "Medium (0.7mm)",
    "thickness.heavy": "Heavy (1.0mm)",

    // Engraving
    "engraving.title": "Custom Engraving (+$3)",
    "engraving.placeholder": "Enter text (max 20 characters)",

    // Pricing
    "price.base": "Base Price:",
    "price.material": "Material:",
    "price.thickness": "Thickness:",
    "price.printing": "Printing:",
    "price.frontDesign": "Front Design:",
    "price.backDesign": "Back Design:",
    "price.engraving": "Custom Engraving:",
    "price.total": "Total Price:",
    "price.addToCart": "Add to Cart",

    // Shop
    "shop.title": "Shop Guitar Picks & Accessories",
    "shop.subtitle": "Discover our complete collection of premium guitar picks and accessories",
    "shop.filters": "Filters",
    "shop.search": "Search Products",
    "shop.searchPlaceholder": "Search picks...",
    "shop.category": "Category",
    "shop.picks": "Guitar Picks",
    "shop.accessories": "Accessories",
    "shop.material": "Material",
    "shop.showing": "Showing",
    "shop.of": "of",
    "shop.products": "products",
    "shop.sortBy": "Sort by",
    "shop.featured": "Featured",
    "shop.priceLow": "Price: Low to High",
    "shop.priceHigh": "Price: High to Low",
    "shop.nameAZ": "Name: A to Z",
    "shop.noProducts": "No products found matching your criteria.",
    "shop.clearFilters": "Clear Filters",

    // Cart
    "cart.title": "Shopping Cart",
    "cart.empty": "Your cart is empty",
    "cart.continue": "Continue Shopping",
    "cart.total": "Total:",
    "cart.checkout": "Checkout",
    "cart.engraved": "Engraved:",

    // Product badges
    "badge.bestSeller": "Best Seller",
    "badge.new": "New",
    "badge.ecoFriendly": "Eco-Friendly",
    "badge.popular": "Popular",

    // Language selector
    "language.select": "Language",
  },

  ro: {
    // Navigation
    "nav.home": "Acasă",
    "nav.shop": "Magazin",
    "nav.customize": "Personalizează",
    "nav.about": "Despre",
    "nav.contact": "Contact",

    // Homepage
    "home.hero.badge": "Penele de Chitară Personalizate",
    "home.hero.title": "Creează-ți Pana Perfectă",
    "home.hero.description":
      "Proiectează penele de chitară personalizate cu customizatorul nostru 3D avansat. Alege materiale, culori și gravuri pentru a crea penele care se potrivesc stilului și sunetului tău.",
    "home.hero.start": "Începe Personalizarea",
    "home.hero.browse": "Răsfoiește Magazinul",
    "home.hero.colors": "Culori Personalizate",
    "home.hero.materials": "Materiale Premium",
    "home.hero.shipping": "Livrare Rapidă",

    // Features
    "features.title": "De Ce Să Alegi Penele Noastre?",
    "features.subtitle": "Penele de chitară de calitate profesională concepute pentru muzicienii care cer cel mai bun",
    "features.materials.title": "Materiale Premium",
    "features.materials.desc": "Materiale de înaltă calitate incluzând celuloid, delrin și lemne exotice",
    "features.design.title": "Design Personalizat",
    "features.design.desc": "Personalizează cu culori, modele și gravuri personalizate",
    "features.delivery.title": "Livrare Rapidă",
    "features.delivery.desc": "Timp de execuție rapid cu opțiuni de livrare express disponibile",
    "features.guarantee.title": "Garanție de Calitate",
    "features.guarantee.desc": "Garanție de returnare a banilor în 30 de zile pentru toate penele personalizate",

    // Customizer
    "customizer.title": "Customizator Avansat",
    "customizer.upload": "Încarcă designuri personalizate",
    "customizer.printing": "Imprimare pe o față sau pe ambele fețe",
    "customizer.preview": "Previzualizare 3D în timp real",
    "customizer.materials": "Materiale și culori multiple",
    "customizer.try": "Încearcă Designerul",

    // CTA
    "cta.title": "Gata să Îți Creezi Pana Perfectă?",
    "cta.subtitle": "Alătură-te miilor de muzicieni care au încredere în penele noastre personalizate",
    "cta.button": "Începe Personalizarea Acum",

    // Customize Page
    "customize.back": "Înapoi la Acasă",
    "customize.title": "Designer de Penele de Chitară Personalizate",
    "customize.subtitle": "Creează-ți pana perfectă cu instrumentele noastre avansate de personalizare",
    "customize.preview": "Previzualizare Pană",
    "customize.front": "Față",
    "customize.back": "Spate",
    "customize.rotation": "Rotație",
    "customize.zoom": "Zoom",
    "customize.reset": "Resetează Vizualizarea",
    "customize.controls": "Folosește controalele de mai sus pentru a roti și mări pana",
    "customize.switch": "Folosește butoanele Față/Spate pentru a comuta între părți",
    "customize.options": "Personalizează-ți Pana",

    // Print Options
    "print.title": "Opțiuni de Imprimare",
    "print.oneSided": "O Față",
    "print.twoSided": "Două Fețe",
    "print.oneSidedDesc": "Design doar pe față",
    "print.twoSidedDesc": "Designuri diferite pe ambele fețe",

    // Design Upload
    "design.front": "Design Față",
    "design.back": "Design Spate",
    "design.viewing": "Se Vizualizează Acum",
    "design.upload": "Încarcă design pentru față",
    "design.uploadBack": "Încarcă design pentru spate",
    "design.fileTypes": "PNG, JPG, GIF până la 5MB",
    "design.choose": "Alege Fișier",
    "design.applied": "Design Față Aplicat",
    "design.appliedBack": "Design Spate Aplicat",
    "design.replace": "Înlocuiește",
    "design.remove": "Elimină",

    // Colors
    "color.title": "Culoare",
    "color.disabled": "(Dezactivat cu design personalizat)",
    "color.white": "Alb",
    "color.yellow": "Galben",
    "color.blue": "Albastru",
    "color.red": "Roșu",
    "color.green": "Verde",
    "color.purple": "Violet",
    "color.orange": "Portocaliu",
    "color.pink": "Roz",
    "color.black": "Negru",

    // Materials
    "material.title": "Material",
    "material.standard": "Standard",
    "material.metal": "Metal",
    "material.wood": "Lemn",
    "material.shiny": "✨ Strălucitor",
    "material.textured": "🌳 Texturat",

    // Thickness
    "thickness.title": "Grosime",
    "thickness.thin": "Subțire (0.5mm)",
    "thickness.medium": "Mediu (0.7mm)",
    "thickness.heavy": "Gros (1.0mm)",

    // Engraving
    "engraving.title": "Gravură Personalizată (+$3)",
    "engraving.placeholder": "Introdu textul (max 20 caractere)",

    // Pricing
    "price.base": "Preț de Bază:",
    "price.material": "Material:",
    "price.thickness": "Grosime:",
    "price.printing": "Imprimare:",
    "price.frontDesign": "Design Față:",
    "price.backDesign": "Design Spate:",
    "price.engraving": "Gravură Personalizată:",
    "price.total": "Preț Total:",
    "price.addToCart": "Adaugă în Coș",

    // Shop
    "shop.title": "Magazin Penele de Chitară și Accesorii",
    "shop.subtitle": "Descoperă colecția noastră completă de penele de chitară premium și accesorii",
    "shop.filters": "Filtre",
    "shop.search": "Caută Produse",
    "shop.searchPlaceholder": "Caută penele...",
    "shop.category": "Categorie",
    "shop.picks": "Penele de Chitară",
    "shop.accessories": "Accesorii",
    "shop.material": "Material",
    "shop.showing": "Se afișează",
    "shop.of": "din",
    "shop.products": "produse",
    "shop.sortBy": "Sortează după",
    "shop.featured": "Recomandate",
    "shop.priceLow": "Preț: De la mic la mare",
    "shop.priceHigh": "Preț: De la mare la mic",
    "shop.nameAZ": "Nume: A la Z",
    "shop.noProducts": "Nu s-au găsit produse care să corespundă criteriilor.",
    "shop.clearFilters": "Șterge Filtrele",

    // Cart
    "cart.title": "Coșul de Cumpărături",
    "cart.empty": "Coșul tău este gol",
    "cart.continue": "Continuă Cumpărăturile",
    "cart.total": "Total:",
    "cart.checkout": "Finalizează Comanda",
    "cart.engraved": "Gravat:",

    // Product badges
    "badge.bestSeller": "Cel Mai Vândut",
    "badge.new": "Nou",
    "badge.ecoFriendly": "Eco-Friendly",
    "badge.popular": "Popular",

    // Language selector
    "language.select": "Limba",
  },

  ru: {
    // Navigation
    "nav.home": "Главная",
    "nav.shop": "Магазин",
    "nav.customize": "Настроить",
    "nav.about": "О нас",
    "nav.contact": "Контакты",

    // Homepage
    "home.hero.badge": "Индивидуальные Медиаторы",
    "home.hero.title": "Создайте Идеальный Медиатор",
    "home.hero.description":
      "Создавайте индивидуальные медиаторы с помощью нашего продвинутого 3D-конструктора. Выбирайте материалы, цвета и гравировки для создания медиаторов, соответствующих вашему стилю и звуку.",
    "home.hero.start": "Начать Настройку",
    "home.hero.browse": "Просмотреть Магазин",
    "home.hero.colors": "Индивидуальные Цвета",
    "home.hero.materials": "Премиум Материалы",
    "home.hero.shipping": "Быстрая Доставка",

    // Features
    "features.title": "Почему Выбирают Наши Медиаторы?",
    "features.subtitle": "Профессиональные медиаторы для гитары, созданные для музыкантов, которые требуют лучшего",
    "features.materials.title": "Премиум Материалы",
    "features.materials.desc": "Высококачественные материалы, включая целлулоид, делрин и экзотические породы дерева",
    "features.design.title": "Индивидуальный Дизайн",
    "features.design.desc": "Персонализируйте цветами, узорами и индивидуальными гравировками",
    "features.delivery.title": "Быстрая Доставка",
    "features.delivery.desc": "Быстрое выполнение с доступными вариантами экспресс-доставки",
    "features.guarantee.title": "Гарантия Качества",
    "features.guarantee.desc": "30-дневная гарантия возврата денег на все индивидуальные медиаторы",

    // Customizer
    "customizer.title": "Продвинутый Конструктор",
    "customizer.upload": "Загрузите индивидуальные дизайны",
    "customizer.printing": "Односторонняя или двусторонняя печать",
    "customizer.preview": "3D-предпросмотр в реальном времени",
    "customizer.materials": "Множество материалов и цветов",
    "customizer.try": "Попробовать Конструктор",

    // CTA
    "cta.title": "Готовы Создать Идеальный Медиатор?",
    "cta.subtitle": "Присоединяйтесь к тысячам музыкантов, которые доверяют нашим индивидуальным медиаторам",
    "cta.button": "Начать Настройку Сейчас",

    // Customize Page
    "customize.back": "Назад на Главную",
    "customize.title": "Конструктор Индивидуальных Медиаторов",
    "customize.subtitle": "Создайте идеальный медиатор с помощью наших продвинутых инструментов настройки",
    "customize.preview": "Предпросмотр Медиатора",
    "customize.front": "Передняя",
    "customize.back": "Задняя",
    "customize.rotation": "Поворот",
    "customize.zoom": "Масштаб",
    "customize.reset": "Сбросить Вид",
    "customize.controls": "Используйте элементы управления выше для поворота и масштабирования медиатора",
    "customize.switch": "Используйте кнопки Передняя/Задняя для переключения сторон",
    "customize.options": "Настройте Ваш Медиатор",

    // Print Options
    "print.title": "Варианты Печати",
    "print.oneSided": "Односторонняя",
    "print.twoSided": "Двусторонняя",
    "print.oneSidedDesc": "Дизайн только на передней стороне",
    "print.twoSidedDesc": "Разные дизайны на обеих сторонах",

    // Design Upload
    "design.front": "Дизайн Передней Стороны",
    "design.back": "Дизайн Задней Стороны",
    "design.viewing": "Сейчас Просматривается",
    "design.upload": "Загрузить дизайн для передней стороны",
    "design.uploadBack": "Загрузить дизайн для задней стороны",
    "design.fileTypes": "PNG, JPG, GIF до 5МБ",
    "design.choose": "Выбрать Файл",
    "design.applied": "Дизайн Передней Стороны Применен",
    "design.appliedBack": "Дизайн Задней Стороны Применен",
    "design.replace": "Заменить",
    "design.remove": "Удалить",

    // Colors
    "color.title": "Цвет",
    "color.disabled": "(Отключено с индивидуальным дизайном)",
    "color.white": "Белый",
    "color.yellow": "Желтый",
    "color.blue": "Синий",
    "color.red": "Красный",
    "color.green": "Зеленый",
    "color.purple": "Фиолетовый",
    "color.orange": "Оранжевый",
    "color.pink": "Розовый",
    "color.black": "Черный",

    // Materials
    "material.title": "Материал",
    "material.standard": "Стандартный",
    "material.metal": "Металл",
    "material.wood": "Дерево",
    "material.shiny": "✨ Блестящий",
    "material.textured": "🌳 Текстурированный",

    // Thickness
    "thickness.title": "Толщина",
    "thickness.thin": "Тонкий (0.5мм)",
    "thickness.medium": "Средний (0.7мм)",
    "thickness.heavy": "Толстый (1.0мм)",

    // Engraving
    "engraving.title": "Индивидуальная Гравировка (+$3)",
    "engraving.placeholder": "Введите текст (макс 20 символов)",

    // Pricing
    "price.base": "Базовая Цена:",
    "price.material": "Материал:",
    "price.thickness": "Толщина:",
    "price.printing": "Печать:",
    "price.frontDesign": "Дизайн Передней Стороны:",
    "price.backDesign": "Дизайн Задней Стороны:",
    "price.engraving": "Индивидуальная Гравировка:",
    "price.total": "Общая Цена:",
    "price.addToCart": "Добавить в Корзину",

    // Shop
    "shop.title": "Магазин Медиаторов и Аксессуаров",
    "shop.subtitle": "Откройте для себя нашу полную коллекцию премиальных медиаторов и аксессуаров",
    "shop.filters": "Фильтры",
    "shop.search": "Поиск Товаров",
    "shop.searchPlaceholder": "Поиск медиаторов...",
    "shop.category": "Категория",
    "shop.picks": "Медиаторы для Гитары",
    "shop.accessories": "Аксессуары",
    "shop.material": "Материал",
    "shop.showing": "Показано",
    "shop.of": "из",
    "shop.products": "товаров",
    "shop.sortBy": "Сортировать по",
    "shop.featured": "Рекомендуемые",
    "shop.priceLow": "Цена: От низкой к высокой",
    "shop.priceHigh": "Цена: От высокой к низкой",
    "shop.nameAZ": "Название: А до Я",
    "shop.noProducts": "Товары, соответствующие вашим критериям, не найдены.",
    "shop.clearFilters": "Очистить Фильтры",

    // Cart
    "cart.title": "Корзина Покупок",
    "cart.empty": "Ваша корзина пуста",
    "cart.continue": "Продолжить Покупки",
    "cart.total": "Итого:",
    "cart.checkout": "Оформить Заказ",
    "cart.engraved": "Гравировка:",

    // Product badges
    "badge.bestSeller": "Бестселлер",
    "badge.new": "Новинка",
    "badge.ecoFriendly": "Эко-Дружественный",
    "badge.popular": "Популярный",

    // Language selector
    "language.select": "Язык",
  },

  zh: {
    // Navigation
    "nav.home": "首页",
    "nav.shop": "商店",
    "nav.customize": "定制",
    "nav.about": "关于",
    "nav.contact": "联系",

    // Homepage
    "home.hero.badge": "定制吉他拨片",
    "home.hero.title": "打造完美拨片",
    "home.hero.description":
      "使用我们先进的3D定制器设计定制吉他拨片。选择材料、颜色和雕刻，创造符合您风格和音色的拨片。",
    "home.hero.start": "开始定制",
    "home.hero.browse": "浏览商店",
    "home.hero.colors": "定制颜色",
    "home.hero.materials": "优质材料",
    "home.hero.shipping": "快速配送",

    // Features
    "features.title": "为什么选择我们的拨片？",
    "features.subtitle": "为要求最佳品质的音乐家设计的专业级吉他拨片",
    "features.materials.title": "优质材料",
    "features.materials.desc": "高品质材料，包括赛璐珞、德林和异国木材",
    "features.design.title": "定制设计",
    "features.design.desc": "用颜色、图案和定制雕刻进行个性化",
    "features.delivery.title": "快速配送",
    "features.delivery.desc": "快速周转，提供快递配送选项",
    "features.guarantee.title": "质量保证",
    "features.guarantee.desc": "所有定制拨片30天退款保证",

    // Customizer
    "customizer.title": "高级定制器",
    "customizer.upload": "上传定制设计",
    "customizer.printing": "单面或双面印刷",
    "customizer.preview": "实时3D预览",
    "customizer.materials": "多种材料和颜色",
    "customizer.try": "试用设计器",

    // CTA
    "cta.title": "准备创造您的完美拨片？",
    "cta.subtitle": "加入数千名信任我们定制吉他拨片的音乐家",
    "cta.button": "立即开始定制",

    // Customize Page
    "customize.back": "返回首页",
    "customize.title": "定制吉他拨片设计器",
    "customize.subtitle": "使用我们先进的定制工具创造您的完美吉他拨片",
    "customize.preview": "拨片预览",
    "customize.front": "正面",
    "customize.back": "背面",
    "customize.rotation": "旋转",
    "customize.zoom": "缩放",
    "customize.reset": "重置视图",
    "customize.controls": "使用上面的控件旋转和缩放拨片",
    "customize.switch": "使用正面/背面按钮切换面",
    "customize.options": "定制您的拨片",

    // Print Options
    "print.title": "印刷选项",
    "print.oneSided": "单面",
    "print.twoSided": "双面",
    "print.oneSidedDesc": "仅正面设计",
    "print.twoSidedDesc": "两面不同设计",

    // Design Upload
    "design.front": "正面设计",
    "design.back": "背面设计",
    "design.viewing": "当前查看",
    "design.upload": "上传正面设计",
    "design.uploadBack": "上传背面设计",
    "design.fileTypes": "PNG、JPG、GIF，最大5MB",
    "design.choose": "选择文件",
    "design.applied": "正面设计已应用",
    "design.appliedBack": "背面设计已应用",
    "design.replace": "替换",
    "design.remove": "移除",

    // Colors
    "color.title": "颜色",
    "color.disabled": "（定制设计时禁用）",
    "color.white": "白色",
    "color.yellow": "黄色",
    "color.blue": "蓝色",
    "color.red": "红色",
    "color.green": "绿色",
    "color.purple": "紫色",
    "color.orange": "橙色",
    "color.pink": "粉色",
    "color.black": "黑色",

    // Materials
    "material.title": "材料",
    "material.standard": "标准",
    "material.metal": "金属",
    "material.wood": "木材",
    "material.shiny": "✨ 闪亮",
    "material.textured": "🌳 纹理",

    // Thickness
    "thickness.title": "厚度",
    "thickness.thin": "薄 (0.5mm)",
    "thickness.medium": "中等 (0.7mm)",
    "thickness.heavy": "厚 (1.0mm)",

    // Engraving
    "engraving.title": "定制雕刻 (+$3)",
    "engraving.placeholder": "输入文字（最多20个字符）",

    // Pricing
    "price.base": "基础价格：",
    "price.material": "材料：",
    "price.thickness": "厚度：",
    "price.printing": "印刷：",
    "price.frontDesign": "正面设计：",
    "price.backDesign": "背面设计：",
    "price.engraving": "定制雕刻：",
    "price.total": "总价：",
    "price.addToCart": "加入购物车",

    // Shop
    "shop.title": "吉他拨片和配件商店",
    "shop.subtitle": "探索我们完整的优质吉他拨片和配件系列",
    "shop.filters": "筛选",
    "shop.search": "搜索产品",
    "shop.searchPlaceholder": "搜索拨片...",
    "shop.category": "类别",
    "shop.picks": "吉他拨片",
    "shop.accessories": "配件",
    "shop.material": "材料",
    "shop.showing": "显示",
    "shop.of": "共",
    "shop.products": "产品",
    "shop.sortBy": "排序方式",
    "shop.featured": "推荐",
    "shop.priceLow": "价格：从低到高",
    "shop.priceHigh": "价格：从高到低",
    "shop.nameAZ": "名称：A到Z",
    "shop.noProducts": "未找到符合您条件的产品。",
    "shop.clearFilters": "清除筛选",

    // Cart
    "cart.title": "购物车",
    "cart.empty": "您的购物车是空的",
    "cart.continue": "继续购物",
    "cart.total": "总计：",
    "cart.checkout": "结账",
    "cart.engraved": "雕刻：",

    // Product badges
    "badge.bestSeller": "畅销",
    "badge.new": "新品",
    "badge.ecoFriendly": "环保",
    "badge.popular": "热门",

    // Language selector
    "language.select": "语言",
  },
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
